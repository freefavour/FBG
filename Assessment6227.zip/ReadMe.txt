1 data from mongodb json has json file of data uploaded to mongo db
2 dataset.csv has disease and symptom data of patient
3 symptom_description.csv has the description of the diseases
4 symptom_severity has the grading scale of the severity
5 analysis of the data and readme files for each disease